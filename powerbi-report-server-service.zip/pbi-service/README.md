# Power BI Report Server Microservice

Standalone, production-grade Java microservice for interacting with
Power BI Report Server (On-Prem). JWT authentication, role-based authorization,
NTLM integration, 30+ API endpoints.

## Quick Start

```bash
# Set environment variables
export PBIRS_PORTAL_URL=https://your-server/reports
export PBIRS_EXECUTION_URL=https://your-server/reportserver
export PBIRS_DOMAIN=YOURCOMPANY
export PBIRS_USERNAME=svc-powerbi-app
export PBIRS_PASSWORD=your_password
export JWT_SECRET=change-this-to-a-long-random-string-at-least-32-chars

# Build and run
mvn clean package -DskipTests
mvn spring-boot:run
# Starts on port 8082
```

## Authentication

All endpoints (except /api/auth/login) require a JWT Bearer token.

```bash
# Login
curl -X POST http://localhost:8082/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Response: { "token": "eyJ...", "roles": ["ADMIN","REPORT_VIEWER",...] }

# Use the token on all subsequent calls
curl -H "Authorization: Bearer eyJ..." http://localhost:8082/api/reports
```

### Default Users (configure in application.yml)

| Username | Password | Roles |
|----------|----------|-------|
| admin | admin123 | ADMIN, REPORT_VIEWER, REPORT_MANAGER, SUBSCRIPTION_MANAGER |
| analyst | analyst123 | REPORT_VIEWER, REPORT_MANAGER |
| viewer | viewer123 | REPORT_VIEWER |

## API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | Login, returns JWT token |
| GET | /api/auth/validate | Validate token, returns user info |

### Reports (REPORT_VIEWER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/reports?folder=/path | List reports in folder |
| GET | /api/reports/details?path=/Report | Get report metadata |
| GET | /api/reports/parameters?path=/Report | Get parameter definitions |
| GET | /api/reports/parameters/values?path=/Report&param=YEAR | Get allowed values |
| GET | /api/reports/history?path=/Report | Get history snapshots |
| GET | /api/reports/comments?path=/Report | Get comments |
| POST | /api/reports/comments?path=/Report | Add a comment |
| GET | /api/reports/datasources?path=/Report | Get data sources used |

### Report Rendering (REPORT_VIEWER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/reports/render?path=/Report&format=PDF&YEAR=2024 | Render report (GET) |
| POST | /api/reports/render | Render report (POST, complex params) |
| GET | /api/reports/embed?path=/Report | Render as embeddable HTML |

Supported formats: PDF, EXCELOPENXML, HTML5, CSV, IMAGE, WORDOPENXML, PPTX

### Report Management (REPORT_MANAGER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/reports/upload | Upload .rdl file |
| DELETE | /api/reports?path=/Report | Delete a report |
| PUT | /api/reports/move | Move or rename a report |

### Subscriptions (SUBSCRIPTION_MANAGER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/subscriptions | List all subscriptions |
| GET | /api/subscriptions/report?path=/Report | List for a specific report |
| GET | /api/subscriptions/{id} | Get subscription details |
| POST | /api/subscriptions | Create (email or file share) |
| PUT | /api/subscriptions/{id}/toggle?active=true | Enable/disable |
| POST | /api/subscriptions/{id}/execute | Run immediately |
| DELETE | /api/subscriptions/{id} | Delete |

### Folders (REPORT_MANAGER)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/folders?parent=/path | List folders |
| POST | /api/folders?name=Sales&parent=/ | Create folder |
| DELETE | /api/folders?path=/Sales | Delete folder |

### Data Sources (ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/datasources | List all data sources |
| GET | /api/datasources/details?path=/DS | Get data source details |
| POST | /api/datasources | Create shared data source |
| POST | /api/datasources/test?path=/DS | Test connection |
| DELETE | /api/datasources?path=/DS | Delete data source |

### System (ADMIN)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/system/health | Full health check with capabilities |
| GET | /api/system/info | Report Server system info |
| GET | /api/system/policies | Server security policies |
| GET | /api/system/ping | Quick connectivity check |

## Project Structure

```
src/main/java/com/powerbi/
├── PowerBIServiceApplication.java
├── client/
│   ├── NtlmHttpClientFactory.java    # NTLM-authenticated HttpClient bean
│   └── ReportServerClient.java       # All Report Server API calls
├── config/
│   └── ReportServerProperties.java   # Type-safe configuration
├── controller/
│   ├── AuthController.java           # Login / token validation
│   ├── ReportController.java         # List, render, upload, delete, move
│   ├── SubscriptionController.java   # Scheduled report delivery
│   ├── FolderController.java         # Folder management
│   ├── DataSourceController.java     # Data source management
│   └── SystemController.java         # Health, info, policies
├── exception/
│   ├── ReportServerException.java    # Custom exception
│   └── GlobalExceptionHandler.java   # Error response formatting
├── model/
│   ├── AuthRequest.java              # Login DTO
│   └── ApiModels.java                # Render, subscription, upload DTOs
└── security/
    ├── JwtTokenProvider.java         # JWT generation / validation
    ├── JwtAuthFilter.java            # Spring Security filter
    └── SecurityConfig.java           # HTTP security + CORS + role mapping
```

## Requirements

- Java 17+
- Maven 3.8+
- Power BI Report Server (On-Prem) with REST API v2.0
- A Windows/AD service account with Browser + Publisher permissions
