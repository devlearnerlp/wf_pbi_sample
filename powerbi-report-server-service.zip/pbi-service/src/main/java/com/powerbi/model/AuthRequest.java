package com.powerbi.model;

import java.util.*;

/** Auth login request */
public record AuthRequest(String username, String password) {}
