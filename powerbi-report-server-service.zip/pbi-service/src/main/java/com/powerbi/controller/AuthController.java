package com.powerbi.controller;

import com.powerbi.model.AuthRequest;
import com.powerbi.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final JwtTokenProvider tokenProvider;

    /** Loaded from application.yml security.users list */
    @Value("#{${security.users}}")
    private List<Map<String, String>> configuredUsers;

    public AuthController(JwtTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    /**
     * POST /api/auth/login
     * Body: { "username": "admin", "password": "admin123" }
     * Returns: { "token": "eyJ...", "username": "admin", "roles": [...], "expiresIn": 86400000 }
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody AuthRequest request) {
        // Find matching user from config
        Map<String, String> found = null;
        if (configuredUsers != null) {
            for (Map<String, String> u : configuredUsers) {
                if (request.username().equals(u.get("username")) && request.password().equals(u.get("password"))) {
                    found = u;
                    break;
                }
            }
        }

        if (found == null) throw new BadCredentialsException("Invalid username or password");

        List<String> roles = Arrays.stream(found.get("roles").split(",")).map(String::trim).collect(Collectors.toList());
        String token = tokenProvider.generateToken(request.username(), roles);

        return ResponseEntity.ok(Map.of(
            "token", token,
            "username", request.username(),
            "roles", roles,
            "expiresIn", 86400000,
            "tokenType", "Bearer"
        ));
    }

    /** GET /api/auth/validate — validates a token and returns user info */
    @GetMapping("/validate")
    public ResponseEntity<Map<String, Object>> validate(@RequestHeader("Authorization") String header) {
        if (header == null || !header.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("valid", false));
        }
        String token = header.substring(7);
        if (!tokenProvider.validate(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("valid", false));
        }
        return ResponseEntity.ok(Map.of(
            "valid", true,
            "username", tokenProvider.getUsername(token),
            "roles", tokenProvider.getRoles(token)
        ));
    }
}
