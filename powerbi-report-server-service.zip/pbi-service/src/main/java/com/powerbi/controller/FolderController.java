package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import org.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/folders")
public class FolderController {
    private final ReportServerClient client;
    public FolderController(ReportServerClient client) { this.client = client; }

    @GetMapping
    public ResponseEntity<JsonNode> list(@RequestParam(defaultValue = "/") String parent) {
        return ResponseEntity.ok(client.listFolders(parent));
    }

    @PostMapping
    @PreAuthorize("hasRole('REPORT_MANAGER')")
    public ResponseEntity<JsonNode> create(@RequestParam String name, @RequestParam(defaultValue = "/") String parent) {
        return ResponseEntity.ok(client.createFolder(name, parent));
    }

    @DeleteMapping
    @PreAuthorize("hasRole('REPORT_MANAGER')")
    public ResponseEntity<Void> delete(@RequestParam String path) {
        client.deleteCatalogItem(path); return ResponseEntity.ok().build();
    }
}
