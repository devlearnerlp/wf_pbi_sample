package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.config.ReportServerProperties;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/system")
public class SystemController {
    private final ReportServerClient client;
    private final ReportServerProperties config;

    public SystemController(ReportServerClient client, ReportServerProperties config) {
        this.client = client; this.config = config;
    }

    /** Full health check — verifies Report Server connectivity */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        boolean reachable = client.isServerReachable();
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("service", "powerbi-report-server-service");
        resp.put("version", "1.0.0");
        resp.put("status", reachable ? "UP" : "DEGRADED");
        resp.put("reportServer", Map.of(
            "portalUrl", config.getPortalUrl(),
            "reachable", reachable
        ));
        resp.put("timestamp", LocalDateTime.now().toString());
        resp.put("supportedFormats", List.of("PDF", "EXCELOPENXML", "HTML5", "CSV", "IMAGE", "WORDOPENXML", "PPTX"));
        resp.put("supportedOperations", List.of(
            "listReports", "getReport", "renderReport", "uploadReport", "deleteReport", "moveReport",
            "getParameters", "getParameterValues",
            "listSubscriptions", "createSubscription", "deleteSubscription", "executeSubscription",
            "listFolders", "createFolder", "deleteFolder",
            "listDataSources", "createDataSource", "testDataSource",
            "getReportHistory", "getReportComments", "addReportComment",
            "getSystemInfo", "getSystemPolicies"
        ));
        return ResponseEntity.ok(resp);
    }

    /** Get Report Server system properties */
    @GetMapping("/info")
    public ResponseEntity<JsonNode> serverInfo() {
        return ResponseEntity.ok(client.getSystemProperties());
    }

    /** Get server security policies */
    @GetMapping("/policies")
    public ResponseEntity<JsonNode> policies() {
        return ResponseEntity.ok(client.getSystemPolicies());
    }

    /** Simple connectivity ping */
    @GetMapping("/ping")
    public ResponseEntity<Map<String, Object>> ping() {
        return ResponseEntity.ok(Map.of(
            "reachable", client.isServerReachable(),
            "portalUrl", config.getPortalUrl(),
            "executionUrl", config.getExecutionUrl(),
            "timestamp", LocalDateTime.now().toString()
        ));
    }
}
