package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import org.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/subscriptions")
public class SubscriptionController {

    private static final Logger log = LoggerFactory.getLogger(SubscriptionController.class);
    private final ReportServerClient client;

    public SubscriptionController(ReportServerClient client) { this.client = client; }

    /** List all subscriptions for a specific report */
    @GetMapping("/report")
    public ResponseEntity<JsonNode> listForReport(@RequestParam String path) {
        return ResponseEntity.ok(client.listSubscriptions(path));
    }

    /** List ALL subscriptions on the server */
    @GetMapping
    public ResponseEntity<JsonNode> listAll() {
        return ResponseEntity.ok(client.listAllSubscriptions());
    }

    /** Get a subscription by ID */
    @GetMapping("/{id}")
    public ResponseEntity<JsonNode> get(@PathVariable String id) {
        return ResponseEntity.ok(client.getSubscription(id));
    }

    /** Create a new subscription (email or file share) */
    @PostMapping
    public ResponseEntity<JsonNode> create(@RequestBody SubscriptionRequest request) {
        log.info("Create subscription: report={}, delivery={}, schedule={}",
            request.getReportPath(), request.getDeliveryType(), request.getSchedule());

        JsonNode result;
        if ("fileshare".equalsIgnoreCase(request.getDeliveryType())) {
            result = client.createFileShareSubscription(
                request.getReportPath(), request.getDescription(),
                request.getSchedule(), request.getFilePath(),
                request.getRenderFormat(), request.getParameters());
        } else {
            result = client.createEmailSubscription(
                request.getReportPath(), request.getDescription(),
                request.getSchedule(), request.getEmailTo(),
                request.getRenderFormat(), request.getParameters());
        }
        return ResponseEntity.ok(result);
    }

    /** Enable or disable a subscription */
    @PutMapping("/{id}/toggle")
    public ResponseEntity<JsonNode> toggle(@PathVariable String id, @RequestParam boolean active) {
        log.info("Toggle subscription {}: active={}", id, active);
        return ResponseEntity.ok(client.toggleSubscription(id, active));
    }

    /** Trigger a subscription to run immediately (execute now) */
    @PostMapping("/{id}/execute")
    public ResponseEntity<Void> execute(@PathVariable String id) {
        log.info("Execute subscription now: {}", id);
        client.executeSubscription(id);
        return ResponseEntity.ok().build();
    }

    /** Delete a subscription */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        log.info("Delete subscription: {}", id);
        client.deleteSubscription(id);
        return ResponseEntity.ok().build();
    }
}
