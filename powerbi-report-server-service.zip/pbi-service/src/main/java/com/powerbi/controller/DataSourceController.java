package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/datasources")
@PreAuthorize("hasRole('ADMIN')")
public class DataSourceController {
    private final ReportServerClient client;
    public DataSourceController(ReportServerClient client) { this.client = client; }

    @GetMapping
    public ResponseEntity<JsonNode> list() { return ResponseEntity.ok(client.listDataSources()); }

    @GetMapping("/details")
    public ResponseEntity<JsonNode> get(@RequestParam String path) { return ResponseEntity.ok(client.getDataSource(path)); }

    @PostMapping
    public ResponseEntity<JsonNode> create(@RequestBody DataSourceRequest req) {
        return ResponseEntity.ok(client.createDataSource(req.getName(), req.getPath(),
            req.getConnectionType(), req.getConnectionString(), req.getUsername(), req.getPassword()));
    }

    @PostMapping("/test")
    public ResponseEntity<JsonNode> test(@RequestParam String path) {
        return ResponseEntity.ok(client.testDataSourceConnection(path));
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestParam String path) {
        client.deleteCatalogItem(path); return ResponseEntity.ok().build();
    }
}
