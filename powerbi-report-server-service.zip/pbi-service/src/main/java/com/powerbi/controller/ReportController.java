package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private static final Logger log = LoggerFactory.getLogger(ReportController.class);
    private final ReportServerClient client;

    public ReportController(ReportServerClient client) { this.client = client; }

    // ═══════════════════════════════════════════════════════════════
    // LIST & GET
    // ═══════════════════════════════════════════════════════════════

    /** List all reports, optionally filtered by folder path */
    @GetMapping
    public ResponseEntity<JsonNode> listReports(@RequestParam(defaultValue = "/") String folder) {
        log.info("List reports: folder={}", folder);
        return ResponseEntity.ok(client.listReports(folder));
    }

    /** Get a single report's metadata */
    @GetMapping("/details")
    public ResponseEntity<JsonNode> getReport(@RequestParam String path) {
        return ResponseEntity.ok(client.getReport(path));
    }

    /** Get parameter definitions for a report */
    @GetMapping("/parameters")
    public ResponseEntity<JsonNode> getParameters(@RequestParam String path) {
        return ResponseEntity.ok(client.getReportParameters(path));
    }

    /** Get allowed values for a specific parameter */
    @GetMapping("/parameters/values")
    public ResponseEntity<JsonNode> getParameterValues(@RequestParam String path, @RequestParam String param) {
        return ResponseEntity.ok(client.getParameterValidValues(path, param));
    }

    /** Get report history snapshots */
    @GetMapping("/history")
    public ResponseEntity<JsonNode> getHistory(@RequestParam String path) {
        return ResponseEntity.ok(client.getReportHistory(path));
    }

    /** Get report comments */
    @GetMapping("/comments")
    public ResponseEntity<JsonNode> getComments(@RequestParam String path) {
        return ResponseEntity.ok(client.getReportComments(path));
    }

    /** Get data sources used by a report */
    @GetMapping("/datasources")
    public ResponseEntity<JsonNode> getReportDataSources(@RequestParam String path) {
        return ResponseEntity.ok(client.getReportDataSources(path));
    }

    // ═══════════════════════════════════════════════════════════════
    // RENDER
    // ═══════════════════════════════════════════════════════════════

    /** Render a report — the main endpoint for generating PDF/Excel/HTML
     *
     * GET /api/reports/render?path=/Sales/Report&format=PDF&YEAR=2024&REGION=West
     */
    @GetMapping("/render")
    public ResponseEntity<byte[]> renderGet(
            @RequestParam String path,
            @RequestParam(defaultValue = "PDF") String format,
            @RequestParam Map<String, String> allParams) {
        Map<String, String> reportParams = new HashMap<>(allParams);
        reportParams.remove("path");
        reportParams.remove("format");
        return doRender(path, format, reportParams, false, false);
    }

    /** Render via POST (for complex parameter sets) */
    @PostMapping("/render")
    public ResponseEntity<byte[]> renderPost(@RequestBody RenderRequest request) {
        return doRender(request.getReportPath(), request.getFormat(),
            request.getParameters(), request.isShowToolbar(), request.isShowParameters());
    }

    /** Render as embeddable HTML (convenience endpoint) */
    @GetMapping("/embed")
    public ResponseEntity<byte[]> embed(
            @RequestParam String path,
            @RequestParam Map<String, String> allParams) {
        Map<String, String> reportParams = new HashMap<>(allParams);
        reportParams.remove("path");
        return doRender(path, "HTML5", reportParams, false, false);
    }

    private ResponseEntity<byte[]> doRender(String path, String format,
            Map<String, String> params, boolean toolbar, boolean showParams) {
        log.info("Render: path={}, format={}, params={}", path, format, params);
        byte[] data = client.renderReport(path, format, params, toolbar, showParams);

        MediaType contentType = switch (format.toUpperCase()) {
            case "PDF" -> MediaType.APPLICATION_PDF;
            case "EXCELOPENXML" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            case "HTML5", "HTML4.0", "MHTML" -> MediaType.TEXT_HTML;
            case "CSV" -> MediaType.parseMediaType("text/csv");
            case "IMAGE" -> MediaType.IMAGE_TIFF;
            case "WORDOPENXML" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
            case "PPTX" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.presentationml.presentation");
            default -> MediaType.APPLICATION_OCTET_STREAM;
        };

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(contentType);

        // Downloadable formats get a filename
        if (!format.toUpperCase().contains("HTML")) {
            String name = path.substring(path.lastIndexOf('/') + 1);
            String ext = switch (format.toUpperCase()) {
                case "PDF" -> ".pdf"; case "EXCELOPENXML" -> ".xlsx"; case "CSV" -> ".csv";
                case "IMAGE" -> ".tiff"; case "WORDOPENXML" -> ".docx"; case "PPTX" -> ".pptx";
                default -> "";
            };
            headers.setContentDisposition(ContentDisposition.attachment().filename(name + ext).build());
        }

        return ResponseEntity.ok().headers(headers).body(data);
    }

    // ═══════════════════════════════════════════════════════════════
    // UPLOAD / DELETE / MOVE
    // ═══════════════════════════════════════════════════════════════

    /** Upload an RDL report file */
    @PostMapping("/upload")
    @PreAuthorize("hasRole('REPORT_MANAGER')")
    public ResponseEntity<JsonNode> uploadReport(
            @RequestParam("file") MultipartFile file,
            @RequestParam String name,
            @RequestParam(defaultValue = "/") String folder) {
        try {
            byte[] content = file.getBytes();
            log.info("Upload report: name={}, folder={}, size={}", name, folder, content.length);
            return ResponseEntity.ok(client.uploadReport(name, folder, content));
        } catch (Exception e) {
            throw new IllegalArgumentException("Upload failed: " + e.getMessage());
        }
    }

    /** Delete a report */
    @DeleteMapping
    @PreAuthorize("hasRole('REPORT_MANAGER')")
    public ResponseEntity<Void> deleteReport(@RequestParam String path) {
        log.info("Delete report: {}", path);
        client.deleteCatalogItem(path);
        return ResponseEntity.ok().build();
    }

    /** Move or rename a report */
    @PutMapping("/move")
    @PreAuthorize("hasRole('REPORT_MANAGER')")
    public ResponseEntity<JsonNode> moveReport(
            @RequestParam String currentPath,
            @RequestParam String newPath,
            @RequestParam(required = false) String newName) {
        log.info("Move report: {} → {}", currentPath, newPath);
        return ResponseEntity.ok(client.moveReport(currentPath, newPath, newName));
    }

    /** Add a comment to a report */
    @PostMapping("/comments")
    public ResponseEntity<JsonNode> addComment(@RequestParam String path, @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(client.addReportComment(path, body.getOrDefault("text", "")));
    }
}
