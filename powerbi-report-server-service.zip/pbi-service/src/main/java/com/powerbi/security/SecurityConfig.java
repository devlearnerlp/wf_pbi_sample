package com.powerbi.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;
import java.util.*;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    @Value("${cors.allowed-origins}")
    private String allowedOrigins;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> cors.configurationSource(corsConfigSource()))
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // Public endpoints
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/actuator/health").permitAll()
                .requestMatchers("/actuator/info").permitAll()

                // Report viewing — REPORT_VIEWER role
                .requestMatchers(HttpMethod.GET, "/api/reports/**").hasRole("REPORT_VIEWER")
                .requestMatchers(HttpMethod.GET, "/api/folders/**").hasRole("REPORT_VIEWER")
                .requestMatchers(HttpMethod.GET, "/api/datasources/**").hasRole("REPORT_VIEWER")
                .requestMatchers(HttpMethod.POST, "/api/reports/render").hasRole("REPORT_VIEWER")

                // Report management — REPORT_MANAGER role
                .requestMatchers(HttpMethod.POST, "/api/reports/**").hasRole("REPORT_MANAGER")
                .requestMatchers(HttpMethod.PUT, "/api/reports/**").hasRole("REPORT_MANAGER")
                .requestMatchers(HttpMethod.DELETE, "/api/reports/**").hasRole("REPORT_MANAGER")
                .requestMatchers(HttpMethod.POST, "/api/folders/**").hasRole("REPORT_MANAGER")
                .requestMatchers(HttpMethod.DELETE, "/api/folders/**").hasRole("REPORT_MANAGER")

                // Subscription management — SUBSCRIPTION_MANAGER role
                .requestMatchers("/api/subscriptions/**").hasRole("SUBSCRIPTION_MANAGER")

                // Admin — ADMIN role
                .requestMatchers("/api/system/**").hasRole("ADMIN")
                .requestMatchers("/api/datasources/**").hasRole("ADMIN")
                .requestMatchers("/actuator/**").hasRole("ADMIN")

                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    private CorsConfigurationSource corsConfigSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList(allowedOrigins.split(",")));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
