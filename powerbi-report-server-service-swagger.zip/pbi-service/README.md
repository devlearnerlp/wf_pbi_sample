# Power BI Report Server Microservice

Standalone Java microservice for Power BI Report Server (On-Prem).
NTLM authentication to Report Server, 25+ API endpoints, no framework-level auth
(add JWT or OAuth2 later based on your org standard).

## Quick Start

```bash
# Set Report Server credentials (environment variables)
export PBIRS_PORTAL_URL=https://your-server/reports
export PBIRS_EXECUTION_URL=https://your-server/reportserver
export PBIRS_DOMAIN=YOURCOMPANY
export PBIRS_USERNAME=svc-powerbi-app
export PBIRS_PASSWORD=your_password

# Build and run
mvn clean package -DskipTests
mvn spring-boot:run
# Starts on port 8082
```

## Test

```bash
# Health check
curl http://localhost:8082/api/system/health

# List reports
curl http://localhost:8082/api/reports

# Get parameters for a report
curl "http://localhost:8082/api/reports/parameters?path=/Sales/Quarterly"

# Render as PDF
curl -o report.pdf "http://localhost:8082/api/reports/render?path=/Sales/Quarterly&format=PDF&YEAR=2024"

# Render as Excel
curl -o report.xlsx "http://localhost:8082/api/reports/render?path=/Sales/Quarterly&format=EXCELOPENXML&YEAR=2024"

# Render as embeddable HTML
curl "http://localhost:8082/api/reports/embed?path=/Sales/Quarterly&YEAR=2024"

# Create scheduled email subscription
curl -X POST http://localhost:8082/api/subscriptions \
  -H "Content-Type: application/json" \
  -d '{
    "reportPath": "/Sales/Quarterly",
    "description": "Weekly sales report",
    "schedule": "2024-01-01T07:00:00",
    "emailTo": "team@company.com",
    "renderFormat": "PDF",
    "parameters": { "YEAR": "2024" }
  }'
```

## API Endpoints

### Reports
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/reports?folder=/path | List reports in folder |
| GET | /api/reports/details?path=/Report | Report metadata |
| GET | /api/reports/parameters?path=/Report | Parameter definitions |
| GET | /api/reports/parameters/values?path=...&param=YEAR | Allowed values for a parameter |
| GET | /api/reports/history?path=/Report | History snapshots |
| GET | /api/reports/comments?path=/Report | Comments |
| POST | /api/reports/comments?path=/Report | Add comment (body: {"text":"..."}) |
| GET | /api/reports/datasources?path=/Report | Data sources used |

### Rendering
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/reports/render?path=...&format=PDF&PARAM=value | Render (simple) |
| POST | /api/reports/render | Render (complex params via JSON body) |
| GET | /api/reports/embed?path=...&PARAM=value | Render as embeddable HTML |

Formats: PDF, EXCELOPENXML, HTML5, CSV, IMAGE, WORDOPENXML, PPTX

### Report Management
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/reports/upload (multipart: file, name, folder) | Upload .rdl |
| DELETE | /api/reports?path=/Report | Delete report |
| PUT | /api/reports/move?currentPath=...&newPath=... | Move/rename |

### Subscriptions (Scheduled Reports)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/subscriptions | List all |
| GET | /api/subscriptions/report?path=/Report | List for a report |
| GET | /api/subscriptions/{id} | Get details |
| POST | /api/subscriptions | Create (email or file share) |
| PUT | /api/subscriptions/{id}/toggle?active=true | Enable/disable |
| POST | /api/subscriptions/{id}/execute | Run now |
| DELETE | /api/subscriptions/{id} | Delete |

### Folders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/folders?parent=/path | List |
| POST | /api/folders?name=Sales&parent=/ | Create |
| DELETE | /api/folders?path=/Sales | Delete |

### Data Sources
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/datasources | List all |
| GET | /api/datasources/details?path=/DS | Details |
| POST | /api/datasources | Create (JSON body) |
| POST | /api/datasources/test?path=/DS | Test connection |
| DELETE | /api/datasources?path=/DS | Delete |

### System
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/system/health | Health + capabilities |
| GET | /api/system/info | Report Server info |
| GET | /api/system/policies | Server policies |
| GET | /api/system/ping | Quick connectivity check |

## Project Structure

```
src/main/java/com/powerbi/
├── PowerBIServiceApplication.java
├── client/
│   ├── NtlmHttpClientFactory.java      # NTLM HttpClient with connection pool
│   └── ReportServerClient.java         # All Report Server API calls (25+)
├── config/
│   ├── ReportServerProperties.java     # Type-safe config binding
│   └── WebConfig.java                  # CORS
├── controller/
│   ├── ReportController.java           # List, render, upload, delete, move
│   ├── SubscriptionController.java     # Scheduled report delivery
│   ├── FolderController.java           # Folder CRUD
│   ├── DataSourceController.java       # Data source management
│   └── SystemController.java           # Health, info, policies
├── exception/
│   ├── ReportServerException.java
│   └── GlobalExceptionHandler.java
└── model/
    └── ApiModels.java                  # Request DTOs
```

## Authentication

**Current:** No application-level auth. All endpoints are open.
NTLM is used internally to authenticate with Report Server.

**To add later:** Drop in JWT or OAuth2 based on your org standard.
The controllers and client code won't change — you just add a
security filter in front of the controllers.

## Requirements

- Java 17+
- Maven 3.8+
- Power BI Report Server (On-Prem) with REST API v2.0
- Windows/AD service account with Browser + Publisher role
