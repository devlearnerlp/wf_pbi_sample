package com.powerbi.exception;

public class ReportServerException extends RuntimeException {
    private final int statusCode;

    public ReportServerException(String message, int statusCode) {
        super(message); this.statusCode = statusCode;
    }
    public ReportServerException(String message, int statusCode, Throwable cause) {
        super(message, cause); this.statusCode = statusCode;
    }
    public int getStatusCode() { return statusCode; }
}
