package com.powerbi.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.*;

@Configuration
@ConfigurationProperties(prefix = "report-server")
public class ReportServerProperties {
    private String portalUrl;
    private String executionUrl;
    private AuthConfig auth = new AuthConfig();
    private PoolConfig pool = new PoolConfig();
    private String tempFolder = "/SelfService";

    // Getters/Setters
    public String getPortalUrl() { return portalUrl; }
    public void setPortalUrl(String v) { this.portalUrl = v; }
    public String getExecutionUrl() { return executionUrl; }
    public void setExecutionUrl(String v) { this.executionUrl = v; }
    public AuthConfig getAuth() { return auth; }
    public void setAuth(AuthConfig v) { this.auth = v; }
    public PoolConfig getPool() { return pool; }
    public void setPool(PoolConfig v) { this.pool = v; }
    public String getTempFolder() { return tempFolder; }
    public void setTempFolder(String v) { this.tempFolder = v; }

    /** REST API v2.0 base URL */
    public String getApiBaseUrl() { return portalUrl + "/api/v2.0"; }

    public static class AuthConfig {
        private String domain;
        private String username;
        private String password;
        private String workstation;

        public String getDomain() { return domain; }
        public void setDomain(String v) { this.domain = v; }
        public String getUsername() { return username; }
        public void setUsername(String v) { this.username = v; }
        public String getPassword() { return password; }
        public void setPassword(String v) { this.password = v; }
        public String getWorkstation() { return workstation; }
        public void setWorkstation(String v) { this.workstation = v; }
    }

    public static class PoolConfig {
        private int maxTotal = 30;
        private int maxPerRoute = 20;
        private int connectionTimeoutMs = 15000;
        private int socketTimeoutMs = 180000;
        private int connectionRequestTimeoutMs = 10000;

        public int getMaxTotal() { return maxTotal; }
        public void setMaxTotal(int v) { this.maxTotal = v; }
        public int getMaxPerRoute() { return maxPerRoute; }
        public void setMaxPerRoute(int v) { this.maxPerRoute = v; }
        public int getConnectionTimeoutMs() { return connectionTimeoutMs; }
        public void setConnectionTimeoutMs(int v) { this.connectionTimeoutMs = v; }
        public int getSocketTimeoutMs() { return socketTimeoutMs; }
        public void setSocketTimeoutMs(int v) { this.socketTimeoutMs = v; }
        public int getConnectionRequestTimeoutMs() { return connectionRequestTimeoutMs; }
        public void setConnectionRequestTimeoutMs(int v) { this.connectionRequestTimeoutMs = v; }
    }
}
