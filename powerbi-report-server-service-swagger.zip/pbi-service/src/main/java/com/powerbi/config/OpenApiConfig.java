package com.powerbi.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.*;
import io.swagger.v3.oas.models.servers.Server;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Power BI Report Server API")
                .version("1.0.0")
                .description("""
                    Production-grade REST API for Power BI Report Server (On-Prem).

                    **Capabilities:**
                    - List, search, and browse reports and folders
                    - Render reports as PDF, Excel, HTML, CSV, Word, PowerPoint, TIFF
                    - Get report parameter definitions and allowed values
                    - Upload, delete, and move reports
                    - Create, manage, and trigger scheduled subscriptions (email / file share)
                    - Manage shared data sources
                    - Server health checks and system info

                    **Authentication:**
                    This service uses NTLM internally to communicate with Report Server.
                    Application-level auth (JWT/OAuth2) can be added based on org standards.
                    """)
                .contact(new Contact()
                    .name("Platform Engineering")
                    .email("platform@company.com"))
                .license(new License()
                    .name("Internal Use")
                    .url("https://company.com")))
            .servers(List.of(
                new Server().url("http://localhost:8082").description("Local Development"),
                new Server().url("https://api.company.com").description("Production")
            ))
            .tags(List.of(
                new Tag().name("Reports").description("List, get metadata, render, upload, delete, and move reports"),
                new Tag().name("Rendering").description("Render reports in various formats (PDF, Excel, HTML, CSV, etc.)"),
                new Tag().name("Subscriptions").description("Schedule reports for automated delivery via email or file share"),
                new Tag().name("Folders").description("Browse and manage the report folder structure"),
                new Tag().name("Data Sources").description("Manage shared data source connections"),
                new Tag().name("System").description("Health checks, server info, and connectivity status")
            ));
    }
}
