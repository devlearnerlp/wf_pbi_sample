package com.powerbi.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.powerbi.config.ReportServerProperties;
import com.powerbi.exception.ReportServerException;
import org.apache.hc.client5.http.classic.methods.*;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.*;
import org.springframework.stereotype.Component;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Low-level HTTP client for Power BI Report Server.
 * Handles NTLM auth, JSON parsing, binary responses, error mapping.
 * All public methods throw ReportServerException on failure.
 */
@Component
public class ReportServerClient {

    private static final Logger log = LoggerFactory.getLogger(ReportServerClient.class);

    private final CloseableHttpClient httpClient;
    private final ReportServerProperties config;
    private final ObjectMapper objectMapper;

    public ReportServerClient(CloseableHttpClient httpClient, ReportServerProperties config, ObjectMapper objectMapper) {
        this.httpClient = httpClient;
        this.config = config;
        this.objectMapper = objectMapper;
    }

    // ═══════════════════════════════════════════════════════════════
    // CATALOG (List/Get/Create/Delete items)
    // ═══════════════════════════════════════════════════════════════

    /** List all catalog items (reports, folders, data sources) in a folder */
    public JsonNode listCatalogItems(String folderPath, String type) {
        StringBuilder url = new StringBuilder(config.getApiBaseUrl() + "/CatalogItems");
        List<String> filters = new ArrayList<>();
        if (folderPath != null && !folderPath.equals("/")) {
            filters.add("startswith(Path,'" + folderPath + "')");
        }
        if (type != null) {
            filters.add("Type eq '" + type + "'");
        }
        if (!filters.isEmpty()) {
            url.append("?$filter=").append(String.join(" and ", filters));
        }
        return getJson(url.toString());
    }

    /** Get a single catalog item by path */
    public JsonNode getCatalogItem(String path) {
        return getJson(config.getApiBaseUrl() + "/CatalogItems(Path='" + encodePath(path) + "')");
    }

    /** Create a folder */
    public JsonNode createFolder(String name, String parentPath) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Name", name);
        body.put("Type", "Folder");
        body.put("Path", parentPath + "/" + name);
        return postJson(config.getApiBaseUrl() + "/CatalogItems", body);
    }

    /** Delete a catalog item */
    public void deleteCatalogItem(String path) {
        delete(config.getApiBaseUrl() + "/CatalogItems(Path='" + encodePath(path) + "')");
    }

    // ═══════════════════════════════════════════════════════════════
    // REPORTS
    // ═══════════════════════════════════════════════════════════════

    /** List all reports, optionally filtered by folder */
    public JsonNode listReports(String folderPath) {
        StringBuilder url = new StringBuilder(config.getApiBaseUrl() + "/Reports");
        if (folderPath != null && !folderPath.equals("/")) {
            url.append("?$filter=startswith(Path,'").append(folderPath).append("')");
        }
        url.append(url.indexOf("?") > 0 ? "&" : "?");
        url.append("$orderby=Name");
        return getJson(url.toString());
    }

    /** Get report metadata by path */
    public JsonNode getReport(String reportPath) {
        return getJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')");
    }

    /** Get report parameter definitions */
    public JsonNode getReportParameters(String reportPath) {
        return getJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/ParameterDefinitions");
    }

    /** Get allowed values for a specific parameter */
    public JsonNode getParameterValidValues(String reportPath, String paramName) {
        JsonNode params = getReportParameters(reportPath);
        if (params.isArray()) {
            for (JsonNode p : params) {
                if (paramName.equals(p.path("Name").asText())) {
                    return p.path("ValidValues");
                }
            }
        }
        return objectMapper.createArrayNode();
    }

    /** Upload an RDL report to Report Server */
    public JsonNode uploadReport(String name, String folderPath, byte[] rdlContent) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Name", name);
        body.put("Type", "Report");
        body.put("Path", folderPath + "/" + name);
        body.put("Content", Base64.getEncoder().encodeToString(rdlContent));
        body.put("ContentType", "");
        return postJson(config.getApiBaseUrl() + "/CatalogItems", body);
    }

    /** Update an existing report's RDL content */
    public void updateReportContent(String reportPath, byte[] rdlContent) {
        Map<String, Object> body = Map.of("Content", Base64.getEncoder().encodeToString(rdlContent));
        patchJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/Content", body);
    }

    /** Move or rename a report */
    public JsonNode moveReport(String currentPath, String newPath, String newName) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Path", newPath);
        if (newName != null) body.put("Name", newName);
        return patchJson(config.getApiBaseUrl() + "/CatalogItems(Path='" + encodePath(currentPath) + "')", body);
    }

    // ═══════════════════════════════════════════════════════════════
    // REPORT RENDERING
    // ═══════════════════════════════════════════════════════════════

    /**
     * Render a report and return the raw bytes.
     * @param reportPath  e.g., "/Sales/Quarterly_Summary"
     * @param format      HTML5, PDF, EXCELOPENXML, CSV, IMAGE, WORDOPENXML, PPTX
     * @param parameters  Report parameter name=value pairs
     */
    public byte[] renderReport(String reportPath, String format, Map<String, String> parameters) {
        StringBuilder url = new StringBuilder(config.getExecutionUrl());
        url.append("?").append(reportPath);
        url.append("&rs:Format=").append(format);
        url.append("&rs:Command=Render");

        if (parameters != null) {
            parameters.forEach((k, v) ->
                url.append("&").append(enc(k)).append("=").append(enc(v))
            );
        }

        log.info("Rendering report: path={}, format={}, params={}", reportPath, format, parameters);
        return getBytes(url.toString());
    }

    /** Render with additional rendering options */
    public byte[] renderReport(String reportPath, String format, Map<String, String> parameters,
                               boolean showToolbar, boolean showParameters) {
        StringBuilder url = new StringBuilder(config.getExecutionUrl());
        url.append("?").append(reportPath);
        url.append("&rs:Format=").append(format);
        url.append("&rs:Command=Render");
        url.append("&rc:Toolbar=").append(showToolbar);
        if (!showParameters) url.append("&rc:Parameters=false");

        if (parameters != null) {
            parameters.forEach((k, v) ->
                url.append("&").append(enc(k)).append("=").append(enc(v))
            );
        }
        return getBytes(url.toString());
    }

    // ═══════════════════════════════════════════════════════════════
    // DATA SOURCES
    // ═══════════════════════════════════════════════════════════════

    /** List all data sources */
    public JsonNode listDataSources() {
        return getJson(config.getApiBaseUrl() + "/DataSources");
    }

    /** Get a data source by path */
    public JsonNode getDataSource(String path) {
        return getJson(config.getApiBaseUrl() + "/DataSources(Path='" + encodePath(path) + "')");
    }

    /** Get data sources used by a specific report */
    public JsonNode getReportDataSources(String reportPath) {
        return getJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/DataSources");
    }

    /** Create a shared data source */
    public JsonNode createDataSource(String name, String path, String connectionType,
                                     String connectionString, String username, String password) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Name", name);
        body.put("Path", path);
        body.put("Type", "DataSource");
        body.put("ConnectionString", connectionString);
        body.put("DataSourceType", connectionType);
        body.put("CredentialRetrieval", "Store");
        body.put("CredentialsByUser", Map.of("UserName", username, "Password", password, "UseAsWindowsCredentials", true));
        return postJson(config.getApiBaseUrl() + "/DataSources", body);
    }

    /** Test a data source connection */
    public JsonNode testDataSourceConnection(String path) {
        return postJson(config.getApiBaseUrl() + "/DataSources(Path='" + encodePath(path) + "')/Model.CheckConnection", Map.of());
    }

    // ═══════════════════════════════════════════════════════════════
    // SUBSCRIPTIONS (Scheduled Reports)
    // ═══════════════════════════════════════════════════════════════

    /** List all subscriptions for a report */
    public JsonNode listSubscriptions(String reportPath) {
        JsonNode report = getReport(reportPath);
        String reportId = report.path("Id").asText();
        return getJson(config.getApiBaseUrl() + "/Subscriptions?$filter=Report/Id eq '" + reportId + "'");
    }

    /** List ALL subscriptions on the server */
    public JsonNode listAllSubscriptions() {
        return getJson(config.getApiBaseUrl() + "/Subscriptions");
    }

    /** Get a subscription by ID */
    public JsonNode getSubscription(String subscriptionId) {
        return getJson(config.getApiBaseUrl() + "/Subscriptions(" + subscriptionId + ")");
    }

    /** Create an email subscription */
    public JsonNode createEmailSubscription(String reportPath, String description,
                                            String schedule, String emailTo,
                                            String renderFormat, Map<String, String> parameters) {
        JsonNode report = getReport(reportPath);
        String reportId = report.path("Id").asText();

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Report", reportPath);
        body.put("Description", description);
        body.put("IsActive", true);
        body.put("EventType", "TimedSubscription");

        // Schedule
        body.put("Schedule", Map.of("Definition", Map.of("StartDateTime", schedule)));

        // Delivery: Email
        List<Map<String, String>> deliveryParams = new ArrayList<>();
        deliveryParams.add(Map.of("Name", "TO", "Value", emailTo));
        deliveryParams.add(Map.of("Name", "RenderFormat", "Value", renderFormat));
        deliveryParams.add(Map.of("Name", "Subject", "Value", "Scheduled: " + reportPath));
        deliveryParams.add(Map.of("Name", "IncludeReport", "Value", "true"));

        body.put("DeliveryExtension", "Report Server Email");
        body.put("ExtensionSettings", Map.of("ParameterValues", deliveryParams));

        // Report parameters
        if (parameters != null && !parameters.isEmpty()) {
            List<Map<String, String>> paramValues = new ArrayList<>();
            parameters.forEach((k, v) -> paramValues.add(Map.of("Name", k, "Value", v)));
            body.put("ParameterValues", paramValues);
        }

        return postJson(config.getApiBaseUrl() + "/Subscriptions", body);
    }

    /** Create a file share subscription */
    public JsonNode createFileShareSubscription(String reportPath, String description,
                                                String schedule, String filePath,
                                                String renderFormat, Map<String, String> parameters) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("Report", reportPath);
        body.put("Description", description);
        body.put("IsActive", true);
        body.put("EventType", "TimedSubscription");
        body.put("Schedule", Map.of("Definition", Map.of("StartDateTime", schedule)));

        List<Map<String, String>> deliveryParams = List.of(
            Map.of("Name", "PATH", "Value", filePath),
            Map.of("Name", "RENDER_FORMAT", "Value", renderFormat),
            Map.of("Name", "FILENAME", "Value", reportPath.substring(reportPath.lastIndexOf('/') + 1)),
            Map.of("Name", "WRITEMODE", "Value", "Overwrite")
        );
        body.put("DeliveryExtension", "Report Server FileShare");
        body.put("ExtensionSettings", Map.of("ParameterValues", deliveryParams));

        if (parameters != null && !parameters.isEmpty()) {
            List<Map<String, String>> pv = new ArrayList<>();
            parameters.forEach((k, v) -> pv.add(Map.of("Name", k, "Value", v)));
            body.put("ParameterValues", pv);
        }

        return postJson(config.getApiBaseUrl() + "/Subscriptions", body);
    }

    /** Enable/disable a subscription */
    public JsonNode toggleSubscription(String subscriptionId, boolean active) {
        return patchJson(config.getApiBaseUrl() + "/Subscriptions(" + subscriptionId + ")",
            Map.of("IsActive", active));
    }

    /** Delete a subscription */
    public void deleteSubscription(String subscriptionId) {
        delete(config.getApiBaseUrl() + "/Subscriptions(" + subscriptionId + ")");
    }

    /** Trigger a subscription to run immediately */
    public void executeSubscription(String subscriptionId) {
        postJson(config.getApiBaseUrl() + "/Subscriptions(" + subscriptionId + ")/Model.Execute", Map.of());
    }

    // ═══════════════════════════════════════════════════════════════
    // FOLDERS
    // ═══════════════════════════════════════════════════════════════

    /** List folders */
    public JsonNode listFolders(String parentPath) {
        return listCatalogItems(parentPath, "Folder");
    }

    // ═══════════════════════════════════════════════════════════════
    // LINKED REPORTS / HISTORY / COMMENTS
    // ═══════════════════════════════════════════════════════════════

    /** Get report history snapshots */
    public JsonNode getReportHistory(String reportPath) {
        return getJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/HistorySnapshots");
    }

    /** Get report comments */
    public JsonNode getReportComments(String reportPath) {
        return getJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/Comments");
    }

    /** Add a comment to a report */
    public JsonNode addReportComment(String reportPath, String text) {
        return postJson(config.getApiBaseUrl() + "/Reports(Path='" + encodePath(reportPath) + "')/Comments",
            Map.of("Body", text));
    }

    // ═══════════════════════════════════════════════════════════════
    // SYSTEM
    // ═══════════════════════════════════════════════════════════════

    /** Get server system properties */
    public JsonNode getSystemProperties() {
        return getJson(config.getApiBaseUrl() + "/System");
    }

    /** Get server system policies (permissions) */
    public JsonNode getSystemPolicies() {
        return getJson(config.getApiBaseUrl() + "/System/Policies");
    }

    /** Check server connectivity (health check) */
    public boolean isServerReachable() {
        try {
            getJson(config.getApiBaseUrl() + "/System");
            return true;
        } catch (Exception e) {
            log.warn("Report Server not reachable: {}", e.getMessage());
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // HTTP EXECUTION LAYER
    // ═══════════════════════════════════════════════════════════════

    private JsonNode getJson(String url) {
        try {
            HttpGet request = new HttpGet(url);
            request.setHeader("Accept", "application/json");
            return httpClient.execute(request, response -> {
                int status = response.getCode();
                String body = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                if (status >= 400) {
                    throw new ReportServerException("GET " + url + " returned " + status + ": " + body, status);
                }
                return objectMapper.readTree(body);
            });
        } catch (ReportServerException e) { throw e; }
        catch (Exception e) { throw new ReportServerException("GET failed: " + url + " - " + e.getMessage(), 500, e); }
    }

    private byte[] getBytes(String url) {
        try {
            HttpGet request = new HttpGet(url);
            return httpClient.execute(request, response -> {
                int status = response.getCode();
                if (status >= 400) {
                    String body = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    throw new ReportServerException("Render failed " + status + ": " + body, status);
                }
                return EntityUtils.toByteArray(response.getEntity());
            });
        } catch (ReportServerException e) { throw e; }
        catch (Exception e) { throw new ReportServerException("Render failed: " + e.getMessage(), 500, e); }
    }

    private JsonNode postJson(String url, Object body) {
        try {
            HttpPost request = new HttpPost(url);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Accept", "application/json");
            request.setEntity(new StringEntity(objectMapper.writeValueAsString(body), ContentType.APPLICATION_JSON));
            return httpClient.execute(request, response -> {
                int status = response.getCode();
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                if (status >= 400) throw new ReportServerException("POST " + url + " returned " + status + ": " + responseBody, status);
                return responseBody.isBlank() ? objectMapper.createObjectNode() : objectMapper.readTree(responseBody);
            });
        } catch (ReportServerException e) { throw e; }
        catch (Exception e) { throw new ReportServerException("POST failed: " + e.getMessage(), 500, e); }
    }

    private JsonNode patchJson(String url, Object body) {
        try {
            HttpPatch request = new HttpPatch(url);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Accept", "application/json");
            request.setEntity(new StringEntity(objectMapper.writeValueAsString(body), ContentType.APPLICATION_JSON));
            return httpClient.execute(request, response -> {
                int status = response.getCode();
                String rb = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                if (status >= 400) throw new ReportServerException("PATCH " + url + " returned " + status + ": " + rb, status);
                return rb.isBlank() ? objectMapper.createObjectNode() : objectMapper.readTree(rb);
            });
        } catch (ReportServerException e) { throw e; }
        catch (Exception e) { throw new ReportServerException("PATCH failed: " + e.getMessage(), 500, e); }
    }

    private void delete(String url) {
        try {
            HttpDelete request = new HttpDelete(url);
            httpClient.execute(request, response -> {
                int status = response.getCode();
                if (status >= 400 && status != 404) {
                    String body = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    throw new ReportServerException("DELETE " + url + " returned " + status + ": " + body, status);
                }
                return null;
            });
        } catch (ReportServerException e) { throw e; }
        catch (Exception e) { throw new ReportServerException("DELETE failed: " + e.getMessage(), 500, e); }
    }

    private String enc(String v) { return URLEncoder.encode(v, StandardCharsets.UTF_8); }
    private String encodePath(String path) { return path.replace("'", "''"); }
}
