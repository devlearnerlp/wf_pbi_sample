package com.powerbi.client;

import com.powerbi.config.ReportServerProperties;
import org.apache.hc.client5.http.auth.*;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.auth.BasicCredentialsProvider;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.http.io.SocketConfig;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Creates a connection-pooled HttpClient with NTLM credentials
 * pre-configured for all requests to Report Server.
 */
@Configuration
public class NtlmHttpClientFactory {

    private static final Logger log = LoggerFactory.getLogger(NtlmHttpClientFactory.class);

    @Bean(destroyMethod = "close")
    public CloseableHttpClient reportServerHttpClient(ReportServerProperties props) {
        ReportServerProperties.AuthConfig auth = props.getAuth();
        ReportServerProperties.PoolConfig pool = props.getPool();

        // NTLM credentials
        BasicCredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(
            new AuthScope(null, -1),
            new NTCredentials(
                auth.getUsername(),
                auth.getPassword().toCharArray(),
                auth.getWorkstation(),
                auth.getDomain()
            )
        );

        // Connection pool
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(pool.getMaxTotal());
        connManager.setDefaultMaxPerRoute(pool.getMaxPerRoute());
        connManager.setDefaultSocketConfig(
            SocketConfig.custom()
                .setSoTimeout(Timeout.ofMilliseconds(pool.getSocketTimeoutMs()))
                .build()
        );

        // Request config
        RequestConfig requestConfig = RequestConfig.custom()
            .setConnectionRequestTimeout(Timeout.ofMilliseconds(pool.getConnectionRequestTimeoutMs()))
            .setResponseTimeout(Timeout.ofMilliseconds(pool.getSocketTimeoutMs()))
            .build();

        log.info("Initialized NTLM HttpClient: domain={}, user={}, pool={}/{}",
            auth.getDomain(), auth.getUsername(), pool.getMaxTotal(), pool.getMaxPerRoute());

        return HttpClients.custom()
            .setDefaultCredentialsProvider(credentialsProvider)
            .setConnectionManager(connManager)
            .setDefaultRequestConfig(requestConfig)
            .build();
    }
}
