package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/subscriptions")
@Tag(name = "Subscriptions", description = "Schedule reports for automated delivery via email or file share")
public class SubscriptionController {

    private static final Logger log = LoggerFactory.getLogger(SubscriptionController.class);
    private final ReportServerClient client;

    public SubscriptionController(ReportServerClient client) { this.client = client; }

    @GetMapping
    @Operation(summary = "List all subscriptions", description = "Returns every subscription configured on the server")
    public ResponseEntity<JsonNode> listAll() {
        return ResponseEntity.ok(client.listAllSubscriptions());
    }

    @GetMapping("/report")
    @Operation(summary = "List subscriptions for a report", description = "Returns subscriptions configured for a specific report")
    public ResponseEntity<JsonNode> listForReport(
            @Parameter(description = "Report path", example = "/Sales/Quarterly", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.listSubscriptions(path));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get subscription details", description = "Returns full details of a specific subscription by ID")
    @ApiResponse(responseCode = "200", description = "Subscription details")
    @ApiResponse(responseCode = "404", description = "Subscription not found")
    public ResponseEntity<JsonNode> get(@Parameter(description = "Subscription ID") @PathVariable String id) {
        return ResponseEntity.ok(client.getSubscription(id));
    }

    @PostMapping
    @Operation(summary = "Create subscription", description = """
        Creates a new scheduled subscription. Supports two delivery types:

        **Email delivery:**
        ```json
        {
          "reportPath": "/Sales/Quarterly",
          "description": "Weekly sales PDF",
          "deliveryType": "email",
          "schedule": "2024-01-01T07:00:00",
          "emailTo": "team@company.com",
          "renderFormat": "PDF",
          "parameters": { "YEAR": "2024" }
        }
        ```

        **File share delivery:**
        ```json
        {
          "reportPath": "/Sales/Quarterly",
          "deliveryType": "fileshare",
          "schedule": "2024-01-01T07:00:00",
          "filePath": "\\\\\\\\server\\\\share\\\\reports",
          "renderFormat": "EXCELOPENXML",
          "parameters": { "YEAR": "2024" }
        }
        ```
        """)
    @ApiResponse(responseCode = "200", description = "Subscription created")
    public ResponseEntity<JsonNode> create(@RequestBody SubscriptionRequest request) {
        log.info("Create subscription: report={}, delivery={}", request.getReportPath(), request.getDeliveryType());
        JsonNode result;
        if ("fileshare".equalsIgnoreCase(request.getDeliveryType())) {
            result = client.createFileShareSubscription(request.getReportPath(), request.getDescription(),
                request.getSchedule(), request.getFilePath(), request.getRenderFormat(), request.getParameters());
        } else {
            result = client.createEmailSubscription(request.getReportPath(), request.getDescription(),
                request.getSchedule(), request.getEmailTo(), request.getRenderFormat(), request.getParameters());
        }
        return ResponseEntity.ok(result);
    }

    @PutMapping("/{id}/toggle")
    @Operation(summary = "Enable or disable subscription", description = "Activates or deactivates a subscription without deleting it")
    public ResponseEntity<JsonNode> toggle(
            @Parameter(description = "Subscription ID") @PathVariable String id,
            @Parameter(description = "Active state", example = "true") @RequestParam boolean active) {
        log.info("Toggle subscription {}: active={}", id, active);
        return ResponseEntity.ok(client.toggleSubscription(id, active));
    }

    @PostMapping("/{id}/execute")
    @Operation(summary = "Execute subscription now", description = "Triggers the subscription to run immediately instead of waiting for the schedule")
    @ApiResponse(responseCode = "200", description = "Execution triggered")
    public ResponseEntity<Void> execute(@Parameter(description = "Subscription ID") @PathVariable String id) {
        log.info("Execute now: {}", id);
        client.executeSubscription(id);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete subscription", description = "Permanently removes a subscription")
    @ApiResponse(responseCode = "200", description = "Deleted")
    public ResponseEntity<Void> delete(@Parameter(description = "Subscription ID") @PathVariable String id) {
        log.info("Delete subscription: {}", id);
        client.deleteSubscription(id);
        return ResponseEntity.ok().build();
    }
}
