package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.config.ReportServerProperties;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/system")
@Tag(name = "System", description = "Health checks, server info, and connectivity status")
public class SystemController {

    private final ReportServerClient client;
    private final ReportServerProperties config;

    public SystemController(ReportServerClient client, ReportServerProperties config) {
        this.client = client; this.config = config;
    }

    @GetMapping("/health")
    @Operation(summary = "Full health check", description = "Checks Report Server connectivity and returns service capabilities including supported formats and operations")
    @ApiResponse(responseCode = "200", description = "Health status with capabilities")
    public ResponseEntity<Map<String, Object>> health() {
        boolean reachable = client.isServerReachable();
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("service", "powerbi-report-server-service");
        resp.put("version", "1.0.0");
        resp.put("status", reachable ? "UP" : "DEGRADED");
        resp.put("reportServer", Map.of("portalUrl", config.getPortalUrl(), "reachable", reachable));
        resp.put("timestamp", LocalDateTime.now().toString());
        resp.put("supportedFormats", List.of("PDF", "EXCELOPENXML", "HTML5", "CSV", "IMAGE", "WORDOPENXML", "PPTX"));
        resp.put("supportedOperations", List.of(
            "listReports", "getReport", "renderReport", "uploadReport", "deleteReport", "moveReport",
            "getParameters", "getParameterValues", "getReportHistory", "getReportComments", "addReportComment",
            "listSubscriptions", "createSubscription", "deleteSubscription", "toggleSubscription", "executeSubscription",
            "listFolders", "createFolder", "deleteFolder",
            "listDataSources", "createDataSource", "testDataSource", "deleteDataSource",
            "getSystemInfo", "getSystemPolicies"
        ));
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/info")
    @Operation(summary = "Report Server info", description = "Returns system-level properties from Report Server (version, edition, features)")
    public ResponseEntity<JsonNode> serverInfo() {
        return ResponseEntity.ok(client.getSystemProperties());
    }

    @GetMapping("/policies")
    @Operation(summary = "Server security policies", description = "Returns the security policies configured at the server level")
    public ResponseEntity<JsonNode> policies() {
        return ResponseEntity.ok(client.getSystemPolicies());
    }

    @GetMapping("/ping")
    @Operation(summary = "Quick connectivity check", description = "Lightweight check — just verifies Report Server is reachable, returns URLs and status")
    @ApiResponse(responseCode = "200", description = "Connectivity status")
    public ResponseEntity<Map<String, Object>> ping() {
        return ResponseEntity.ok(Map.of(
            "reachable", client.isServerReachable(),
            "portalUrl", config.getPortalUrl(),
            "executionUrl", config.getExecutionUrl(),
            "timestamp", LocalDateTime.now().toString()
        ));
    }
}
