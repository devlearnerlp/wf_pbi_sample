package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/datasources")
@Tag(name = "Data Sources", description = "Manage shared data source connections")
public class DataSourceController {

    private final ReportServerClient client;
    public DataSourceController(ReportServerClient client) { this.client = client; }

    @GetMapping
    @Operation(summary = "List data sources", description = "Returns all shared data sources configured on Report Server")
    public ResponseEntity<JsonNode> list() {
        return ResponseEntity.ok(client.listDataSources());
    }

    @GetMapping("/details")
    @Operation(summary = "Get data source details", description = "Returns connection info for a specific data source (credentials are masked)")
    @ApiResponse(responseCode = "404", description = "Data source not found")
    public ResponseEntity<JsonNode> get(
            @Parameter(description = "Data source path", example = "/DataSources/ProductionDB", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getDataSource(path));
    }

    @PostMapping
    @Operation(summary = "Create data source", description = """
        Creates a new shared data source on Report Server.

        ```json
        {
          "name": "ProductionDB",
          "path": "/DataSources/ProductionDB",
          "connectionType": "SQL",
          "connectionString": "Data Source=server;Initial Catalog=mydb",
          "username": "db_reader",
          "password": "secret"
        }
        ```
        """)
    @ApiResponse(responseCode = "200", description = "Data source created")
    public ResponseEntity<JsonNode> create(@RequestBody DataSourceRequest req) {
        return ResponseEntity.ok(client.createDataSource(
            req.getName(), req.getPath(), req.getConnectionType(),
            req.getConnectionString(), req.getUsername(), req.getPassword()));
    }

    @PostMapping("/test")
    @Operation(summary = "Test connection", description = "Tests whether Report Server can connect to the database using this data source")
    @ApiResponse(responseCode = "200", description = "Connection test result")
    public ResponseEntity<JsonNode> test(
            @Parameter(description = "Data source path", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.testDataSourceConnection(path));
    }

    @DeleteMapping
    @Operation(summary = "Delete data source", description = "Removes a shared data source from Report Server")
    @ApiResponse(responseCode = "200", description = "Deleted")
    public ResponseEntity<Void> delete(
            @Parameter(description = "Data source path", required = true) @RequestParam String path) {
        client.deleteCatalogItem(path);
        return ResponseEntity.ok().build();
    }
}
