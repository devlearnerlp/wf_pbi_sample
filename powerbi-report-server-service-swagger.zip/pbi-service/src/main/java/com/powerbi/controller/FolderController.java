package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/folders")
@Tag(name = "Folders", description = "Browse and manage the report folder structure")
public class FolderController {

    private final ReportServerClient client;
    public FolderController(ReportServerClient client) { this.client = client; }

    @GetMapping
    @Operation(summary = "List folders", description = "Returns all folders under the specified parent path")
    public ResponseEntity<JsonNode> list(
            @Parameter(description = "Parent folder path", example = "/") @RequestParam(defaultValue = "/") String parent) {
        return ResponseEntity.ok(client.listFolders(parent));
    }

    @PostMapping
    @Operation(summary = "Create folder", description = "Creates a new folder on Report Server")
    @ApiResponse(responseCode = "200", description = "Folder created")
    public ResponseEntity<JsonNode> create(
            @Parameter(description = "Folder name", example = "Sales", required = true) @RequestParam String name,
            @Parameter(description = "Parent path", example = "/") @RequestParam(defaultValue = "/") String parent) {
        return ResponseEntity.ok(client.createFolder(name, parent));
    }

    @DeleteMapping
    @Operation(summary = "Delete folder", description = "Deletes a folder and all its contents")
    @ApiResponse(responseCode = "200", description = "Deleted")
    @ApiResponse(responseCode = "404", description = "Folder not found")
    public ResponseEntity<Void> delete(
            @Parameter(description = "Folder path to delete", required = true) @RequestParam String path) {
        client.deleteCatalogItem(path);
        return ResponseEntity.ok().build();
    }
}
