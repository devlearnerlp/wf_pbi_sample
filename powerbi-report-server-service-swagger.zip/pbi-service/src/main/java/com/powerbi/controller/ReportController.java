package com.powerbi.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.powerbi.client.ReportServerClient;
import com.powerbi.model.ApiModels.*;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;

@RestController
@RequestMapping("/api/reports")
@Tag(name = "Reports", description = "List, get metadata, render, upload, delete, and move reports")
public class ReportController {

    private static final Logger log = LoggerFactory.getLogger(ReportController.class);
    private final ReportServerClient client;

    public ReportController(ReportServerClient client) { this.client = client; }

    @GetMapping
    @Operation(summary = "List reports", description = "Returns all reports, optionally filtered by folder path")
    @ApiResponse(responseCode = "200", description = "List of reports")
    public ResponseEntity<JsonNode> listReports(
            @Parameter(description = "Folder path to filter, e.g. /Sales", example = "/") @RequestParam(defaultValue = "/") String folder) {
        log.info("List reports: folder={}", folder);
        return ResponseEntity.ok(client.listReports(folder));
    }

    @GetMapping("/details")
    @Operation(summary = "Get report details", description = "Returns metadata for a single report including Id, Name, Path, Type, HasParameters")
    @ApiResponse(responseCode = "200", description = "Report metadata")
    @ApiResponse(responseCode = "404", description = "Report not found")
    public ResponseEntity<JsonNode> getReport(
            @Parameter(description = "Full report path", example = "/Sales/Quarterly_Summary", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getReport(path));
    }

    @GetMapping("/parameters")
    @Operation(summary = "Get report parameters", description = "Returns parameter definitions including name, type, default value, and whether prompting is required")
    @ApiResponse(responseCode = "200", description = "Parameter definitions array")
    public ResponseEntity<JsonNode> getParameters(
            @Parameter(description = "Report path", example = "/Sales/Quarterly_Summary", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getReportParameters(path));
    }

    @GetMapping("/parameters/values")
    @Operation(summary = "Get allowed values for a parameter", description = "Returns the list of valid values for a specific report parameter (for building dropdowns in UI)")
    @ApiResponse(responseCode = "200", description = "Valid values array")
    public ResponseEntity<JsonNode> getParameterValues(
            @Parameter(description = "Report path", required = true) @RequestParam String path,
            @Parameter(description = "Parameter name", example = "FISCAL_YEAR", required = true) @RequestParam String param) {
        return ResponseEntity.ok(client.getParameterValidValues(path, param));
    }

    @GetMapping("/history")
    @Operation(summary = "Get report history", description = "Returns execution history snapshots for a report")
    public ResponseEntity<JsonNode> getHistory(
            @Parameter(description = "Report path", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getReportHistory(path));
    }

    @GetMapping("/comments")
    @Operation(summary = "Get report comments", description = "Returns user comments attached to a report")
    public ResponseEntity<JsonNode> getComments(
            @Parameter(description = "Report path", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getReportComments(path));
    }

    @PostMapping("/comments")
    @Operation(summary = "Add comment to report", description = "Adds a text comment to a report")
    @ApiResponse(responseCode = "200", description = "Comment created")
    public ResponseEntity<JsonNode> addComment(
            @Parameter(description = "Report path", required = true) @RequestParam String path,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(client.addReportComment(path, body.getOrDefault("text", "")));
    }

    @GetMapping("/datasources")
    @Operation(summary = "Get report data sources", description = "Returns data sources used by a specific report")
    public ResponseEntity<JsonNode> getReportDataSources(
            @Parameter(description = "Report path", required = true) @RequestParam String path) {
        return ResponseEntity.ok(client.getReportDataSources(path));
    }

    // ═══ RENDERING ═══════════════════════════════════════════════

    @GetMapping("/render")
    @Tag(name = "Rendering")
    @Operation(summary = "Render report (GET)", description = """
        Renders a report and returns the output in the requested format.
        Pass report parameters as additional query parameters.

        **Example:** `/api/reports/render?path=/Sales/Q4&format=PDF&YEAR=2024&REGION=West`

        **Supported formats:** PDF, EXCELOPENXML, HTML5, CSV, IMAGE (TIFF), WORDOPENXML, PPTX
        """)
    @ApiResponse(responseCode = "200", description = "Rendered report bytes",
        content = @Content(mediaType = "application/octet-stream"))
    @ApiResponse(responseCode = "502", description = "Report Server rendering failed")
    public ResponseEntity<byte[]> renderGet(
            @Parameter(description = "Report path", example = "/Sales/Quarterly_Summary", required = true) @RequestParam String path,
            @Parameter(description = "Output format", example = "PDF", schema = @Schema(allowableValues = {"PDF","EXCELOPENXML","HTML5","CSV","IMAGE","WORDOPENXML","PPTX"})) @RequestParam(defaultValue = "PDF") String format,
            @Parameter(description = "Report parameters as key=value query params") @RequestParam Map<String, String> allParams) {
        Map<String, String> reportParams = new HashMap<>(allParams);
        reportParams.remove("path");
        reportParams.remove("format");
        return doRender(path, format, reportParams, false, false);
    }

    @PostMapping("/render")
    @Tag(name = "Rendering")
    @Operation(summary = "Render report (POST)", description = "Renders a report using a JSON request body — use when parameters are complex or numerous")
    @ApiResponse(responseCode = "200", description = "Rendered report bytes")
    public ResponseEntity<byte[]> renderPost(@RequestBody RenderRequest request) {
        return doRender(request.getReportPath(), request.getFormat(),
            request.getParameters(), request.isShowToolbar(), request.isShowParameters());
    }

    @GetMapping("/embed")
    @Tag(name = "Rendering")
    @Operation(summary = "Render as embeddable HTML", description = "Renders a report as HTML5 suitable for embedding in an iframe. Toolbar and parameter bar are hidden.")
    @ApiResponse(responseCode = "200", description = "HTML content", content = @Content(mediaType = "text/html"))
    public ResponseEntity<byte[]> embed(
            @Parameter(description = "Report path", required = true) @RequestParam String path,
            @Parameter(description = "Report parameters") @RequestParam Map<String, String> allParams) {
        Map<String, String> reportParams = new HashMap<>(allParams);
        reportParams.remove("path");
        return doRender(path, "HTML5", reportParams, false, false);
    }

    private ResponseEntity<byte[]> doRender(String path, String format, Map<String, String> params, boolean toolbar, boolean showParams) {
        log.info("Render: path={}, format={}, params={}", path, format, params);
        byte[] data = client.renderReport(path, format, params, toolbar, showParams);
        MediaType ct = switch (format.toUpperCase()) {
            case "PDF" -> MediaType.APPLICATION_PDF;
            case "EXCELOPENXML" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            case "HTML5", "HTML4.0", "MHTML" -> MediaType.TEXT_HTML;
            case "CSV" -> MediaType.parseMediaType("text/csv");
            case "IMAGE" -> MediaType.IMAGE_TIFF;
            case "WORDOPENXML" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
            case "PPTX" -> MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.presentationml.presentation");
            default -> MediaType.APPLICATION_OCTET_STREAM;
        };
        HttpHeaders h = new HttpHeaders();
        h.setContentType(ct);
        if (!format.toUpperCase().contains("HTML")) {
            String name = path.substring(path.lastIndexOf('/') + 1);
            String ext = switch (format.toUpperCase()) { case "PDF" -> ".pdf"; case "EXCELOPENXML" -> ".xlsx"; case "CSV" -> ".csv"; case "IMAGE" -> ".tiff"; case "WORDOPENXML" -> ".docx"; case "PPTX" -> ".pptx"; default -> ""; };
            h.setContentDisposition(ContentDisposition.attachment().filename(name + ext).build());
        }
        return ResponseEntity.ok().headers(h).body(data);
    }

    // ═══ MANAGEMENT ══════════════════════════════════════════════

    @PostMapping("/upload")
    @Operation(summary = "Upload RDL report", description = "Uploads an .rdl file to Report Server in the specified folder")
    @ApiResponse(responseCode = "200", description = "Upload successful, returns catalog item metadata")
    public ResponseEntity<JsonNode> uploadReport(
            @Parameter(description = "RDL file") @RequestParam("file") MultipartFile file,
            @Parameter(description = "Report name", example = "Quarterly_Sales", required = true) @RequestParam String name,
            @Parameter(description = "Target folder", example = "/Sales") @RequestParam(defaultValue = "/") String folder) {
        try {
            log.info("Upload: name={}, folder={}, size={}", name, folder, file.getSize());
            return ResponseEntity.ok(client.uploadReport(name, folder, file.getBytes()));
        } catch (Exception e) { throw new IllegalArgumentException("Upload failed: " + e.getMessage()); }
    }

    @DeleteMapping
    @Operation(summary = "Delete report", description = "Permanently deletes a report from Report Server")
    @ApiResponse(responseCode = "200", description = "Deleted")
    @ApiResponse(responseCode = "404", description = "Report not found")
    public ResponseEntity<Void> deleteReport(
            @Parameter(description = "Report path to delete", required = true) @RequestParam String path) {
        log.info("Delete: {}", path);
        client.deleteCatalogItem(path);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/move")
    @Operation(summary = "Move or rename report", description = "Moves a report to a new path and/or renames it")
    @ApiResponse(responseCode = "200", description = "Moved successfully")
    public ResponseEntity<JsonNode> moveReport(
            @Parameter(description = "Current path", required = true) @RequestParam String currentPath,
            @Parameter(description = "New path", required = true) @RequestParam String newPath,
            @Parameter(description = "New name (optional)") @RequestParam(required = false) String newName) {
        log.info("Move: {} → {}", currentPath, newPath);
        return ResponseEntity.ok(client.moveReport(currentPath, newPath, newName));
    }
}
