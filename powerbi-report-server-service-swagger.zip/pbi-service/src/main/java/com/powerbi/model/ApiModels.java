package com.powerbi.model;

import java.util.*;

public class ApiModels {

    /** Request to render a report */
    public static class RenderRequest {
        private String reportPath;
        private String format = "PDF";           // PDF, EXCELOPENXML, HTML5, CSV, IMAGE, WORDOPENXML, PPTX
        private Map<String, String> parameters = new LinkedHashMap<>();
        private boolean showToolbar = false;
        private boolean showParameters = false;

        public String getReportPath() { return reportPath; }
        public void setReportPath(String r) { this.reportPath = r; }
        public String getFormat() { return format; }
        public void setFormat(String f) { this.format = f; }
        public Map<String, String> getParameters() { return parameters; }
        public void setParameters(Map<String, String> p) { this.parameters = p; }
        public boolean isShowToolbar() { return showToolbar; }
        public void setShowToolbar(boolean s) { this.showToolbar = s; }
        public boolean isShowParameters() { return showParameters; }
        public void setShowParameters(boolean s) { this.showParameters = s; }
    }

    /** Request to create a subscription */
    public static class SubscriptionRequest {
        private String reportPath;
        private String description;
        private String deliveryType = "email";    // email, fileshare
        private String schedule;                   // ISO datetime: 2024-01-01T07:00:00
        private String emailTo;
        private String filePath;                   // for fileshare delivery
        private String renderFormat = "PDF";
        private Map<String, String> parameters = new LinkedHashMap<>();

        public String getReportPath() { return reportPath; }
        public void setReportPath(String r) { this.reportPath = r; }
        public String getDescription() { return description; }
        public void setDescription(String d) { this.description = d; }
        public String getDeliveryType() { return deliveryType; }
        public void setDeliveryType(String d) { this.deliveryType = d; }
        public String getSchedule() { return schedule; }
        public void setSchedule(String s) { this.schedule = s; }
        public String getEmailTo() { return emailTo; }
        public void setEmailTo(String e) { this.emailTo = e; }
        public String getFilePath() { return filePath; }
        public void setFilePath(String f) { this.filePath = f; }
        public String getRenderFormat() { return renderFormat; }
        public void setRenderFormat(String r) { this.renderFormat = r; }
        public Map<String, String> getParameters() { return parameters; }
        public void setParameters(Map<String, String> p) { this.parameters = p; }
    }

    /** Request to upload a report */
    public static class UploadReportRequest {
        private String name;
        private String folderPath;

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getFolderPath() { return folderPath; }
        public void setFolderPath(String f) { this.folderPath = f; }
    }

    /** Request to create a data source */
    public static class DataSourceRequest {
        private String name;
        private String path;
        private String connectionType = "SQL";     // SQL, Oracle, ODBC
        private String connectionString;
        private String username;
        private String password;

        public String getName() { return name; }
        public void setName(String n) { this.name = n; }
        public String getPath() { return path; }
        public void setPath(String p) { this.path = p; }
        public String getConnectionType() { return connectionType; }
        public void setConnectionType(String c) { this.connectionType = c; }
        public String getConnectionString() { return connectionString; }
        public void setConnectionString(String c) { this.connectionString = c; }
        public String getUsername() { return username; }
        public void setUsername(String u) { this.username = u; }
        public String getPassword() { return password; }
        public void setPassword(String p) { this.password = p; }
    }
}
